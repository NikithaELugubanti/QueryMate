QA_DATA = {
    "what is the category of cap": "Accessories",
    "what is the category of hoodie": "Men",
    "what is the price of frock": "249.00",
    "what is the price of cap": "199.00",
    "what is the category of skirts": "Women",
    "on which date order id 121 was placed": "2023-12-05",
    "what is the customer id of order id 117": "C118",
    "what is the order id of customer name buffay rosh":"O113",
    "what products comes under the category accessories":"Cap, Perfume & Cologne, Watch, Belt",
    "what is the customer name of the customer id 102":"Alice Brown",
    "what is the number of orders placed by the customer id 115":"5"
}
