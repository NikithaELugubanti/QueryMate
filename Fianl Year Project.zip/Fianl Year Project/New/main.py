import streamlit as st
import speech_recognition as sr
from deep_translator import GoogleTranslator
from langdetect import detect
from qa_data import QA_DATA

st.title("Atliq T-Shirts 👕🏢")

st.markdown("<h4>Type or speak your question below to receive an appropriate response.</h4>", unsafe_allow_html=True)

def translate_text(text, target_lang='en'):
    detected_lang = detect(text)
    if detected_lang != target_lang:
        return GoogleTranslator(source=detected_lang, target=target_lang).translate(text), detected_lang
    return text, detected_lang

def recognize_speech():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        listening_message = st.empty()
        listening_message.info("Listening...")
        try:
            audio = r.listen(source)
            text = r.recognize_google(audio)
            listening_message.empty()
            st.success(f"You said: {text}")
            return text
        except sr.UnknownValueError:
            listening_message.empty()
            st.error("Sorry, could not understand audio.")
        except sr.RequestError:
            listening_message.empty()
            st.error("Could not request results, please try again.")
    return ""

col1, col2 = st.columns([4, 1])

with col1:
    
    user_question = st.text_input("Your Question:","")

with col2:
    if st.button("Speak"):
        spoken_text = recognize_speech()
        if spoken_text:
            user_question = spoken_text  # Assign recognized speech to user_question

if user_question:
    translated_question, detected_lang = translate_text(user_question)
    
    # Normalize question (lowercase, strip spaces, remove extra spaces)
    normalized_question = " ".join(translated_question.strip().lower().replace("?","").split())

    # Display normalized question for debugging
    #st.markdown(f"<h6>Normalized Question: {normalized_question}</h6>", unsafe_allow_html=True)

    # Retrieve response from QA_DATA
    response = QA_DATA.get(normalized_question)

    st.markdown(f"<h4>Response: <b>{response}</b></h4>", unsafe_allow_html=True)
